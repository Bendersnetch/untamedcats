package fr.sae.menus;

import java.awt.Font;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;

import fr.sae.game.Global;

public class ClassesSelect extends BasicGameState {
    private TrueTypeFont font, titleFont, menuFont;
    private String firstClass = "";
    private String secondClass = "";
    private String[] descriptions = {
            "Une guerrière excellente dans tous les arts, forte et robuste, elle saura faire face à toutes les situations.",
            "Un combattant impitoyable qui n'a pas peur de se prendre des coups pour affaiblir l'ennemi. Plus il s'approche de la mort, plus sa force augmente.",
            "Une alchimiste, mais pas n'importe qui, une des plus grandes alchimistes qui saura sans mal redonner de la force à ses alliés.",
            "Un redoutable grand-père armé de sa canne à l'allure chétive, mais sous cette faible apparence se trouve un grand mage."
    };

    private String[] classes = {"Swordman", "Berserker", "Healer", "Mage"};
    private int selectedItemIndex = 0;
    private boolean isFirstClassSelected = false;
    private boolean isConfirmationVisible = false;
    private boolean isConfirmSelected = true;

    public ClassesSelect(int stateID) {
    }
    
    private StateBasedGame game;

    @Override
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        this.game = sbg;
        
        // Initialize fonts for rendering text
        Font awtFont = new Font("Verdana", Font.BOLD, 24);
        font = new TrueTypeFont(awtFont, true);

        Font awtTitleFont = new Font("Verdana", Font.BOLD, 36);
        titleFont = new TrueTypeFont(awtTitleFont, true);

        Font awtMenuFont = new Font("Verdana", Font.PLAIN, 24);
        menuFont = new TrueTypeFont(awtMenuFont, true);
        
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException {
        // Set background color
        g.setColor(Color.black);
        g.fillRect(0, 0, gc.getWidth(), gc.getHeight());

        // Render title
        g.setFont(titleFont);
        g.setColor(Color.green);
        g.drawString("SELECT YOUR CLASS", (gc.getWidth() - titleFont.getWidth("SELECT YOUR CLASS")) / 2, gc.getHeight() * 1/10);

        // Render menu items
        g.setFont(menuFont);
        int y = gc.getHeight() * 1/3;
        for (int i = 0; i < classes.length; i++) {
            int x = (gc.getWidth() - menuFont.getWidth(classes[i])) / 2;
            if (i == selectedItemIndex) {
                g.setColor(Color.green);
                g.fillRect(x - 10, y - 10, menuFont.getWidth(classes[i]) + 20, menuFont.getHeight(classes[i]) + 20);
                g.setColor(Color.black);
            } else {
                g.setColor(Color.white);
            }
            g.drawString(classes[i], x, y);
            y += 50;
        }

        // Render selected classes
        g.setColor(Color.white);
        g.drawString("Première classe : " + firstClass, 50, 50);
        g.drawString("Deuxième classe : " + secondClass, 50, 80);

        // Render instructions on the right side
        g.drawString("Utilisez les flèches directionnelles pour naviguer.", gc.getWidth() - menuFont.getWidth("Utilisez les flèches directionnelles pour naviguer.") - 50, 50);
        g.drawString("Appuyez sur Entrée pour valider.", gc.getWidth() - menuFont.getWidth("Appuyez sur Entrée pour valider.") - 50, 80);

        // Render confirmation options if visible
        if (isConfirmationVisible) {
            String confirmOption = "Confirmer";
            String cancelOption = "Annuler";
            int confirmOptionWidth = menuFont.getWidth(confirmOption);
            int cancelOptionWidth = menuFont.getWidth(cancelOption);
            int margin = 50;
            int xConfirm = (gc.getWidth() - confirmOptionWidth) / 2 - 100;
            int xCancel = (gc.getWidth() - cancelOptionWidth) / 2 + 100;
            int yOption = gc.getHeight() - menuFont.getHeight(confirmOption) - margin;
            if (isConfirmSelected) {
                g.setColor(Color.green);
                g.fillRect(xConfirm - 10, yOption - 10, confirmOptionWidth + 20, menuFont.getHeight(confirmOption) + 20);
                g.setColor(Color.black);
                g.drawString(confirmOption, xConfirm, yOption);
                g.setColor(Color.white);
                g.drawString(cancelOption, xCancel, yOption);
            } else {
                g.setColor(Color.green);
                g.fillRect(xCancel - 10, yOption - 10, cancelOptionWidth + 20, menuFont.getHeight(cancelOption) + 20);
                g.setColor(Color.black);
                g.drawString(cancelOption, xCancel, yOption);
                g.setColor(Color.white);
                g.drawString(confirmOption, xConfirm, yOption);
            }
        }

        // Render description if confirmation is not visible
        if (!isConfirmationVisible) {
            String descriptionTitle = "Description :";
            String description = descriptions[selectedItemIndex];
            int descriptionTitleX = (gc.getWidth() - menuFont.getWidth(descriptionTitle)) / 2;
            int descriptionX = (gc.getWidth() - menuFont.getWidth(description)) / 2;
            int descriptionY = gc.getHeight() - menuFont.getHeight(description) - 100;
            g.drawString(descriptionTitle, descriptionTitleX, descriptionY);
            g.drawString(description, descriptionX, descriptionY + 30);
        }
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException {
        // Update method not used in this context
    }

    @Override
    public void keyPressed(int key, char c) {
        if (!isConfirmationVisible) {
            // Handle key presses when confirmation is not visible
            if (key == Input.KEY_UP) {
                selectedItemIndex = (selectedItemIndex - 1 + classes.length) % classes.length;
            } else if (key == Input.KEY_DOWN) {
                selectedItemIndex = (selectedItemIndex + 1) % classes.length;
            } else if (key == Input.KEY_ENTER) {
                // Select first or second class based on user input
                if (!isFirstClassSelected) {
                    firstClass = classes[selectedItemIndex];
                    isFirstClassSelected = true;
                } else {
                    if (!classes[selectedItemIndex].equals(firstClass)) {
                        secondClass = classes[selectedItemIndex];
                        isConfirmationVisible = true;
                    }
                }
            }
        } else {
            // Handle key presses when confirmation is visible
            if (key == Input.KEY_ENTER) {
                if (isConfirmSelected) {
                    // Confirm selection and transition to next game state
                    Global.Player1Classe = firstClass;
                    Global.Player2Classe = secondClass;
                    game.enterState(6); // Enter the game state
                } else {
                    // Cancel selection and reset
                    isFirstClassSelected = false;
                    firstClass = "";
                    secondClass = "";
                    isConfirmationVisible = false;
                }
            } else if (key == Input.KEY_LEFT || key == Input.KEY_RIGHT) {
                // Toggle between confirmation options
                isConfirmSelected = !isConfirmSelected;
            }
        }
    }

    @Override
    public int getID() {
        return 5; // Return the state ID of this state
    }
}
